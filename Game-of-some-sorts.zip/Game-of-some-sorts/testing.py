import time


synonyms= {
  "quit":['exit','quit','e','q','leave','x'],
  "return":['r','return','back'],
  "main":['m','main'],
  "menu":['mm','menu','main menu'],
  "bag":['bag','backpack','bp',]
}
print(synonyms.values())
