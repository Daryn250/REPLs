import os
import time
import random
import subprocess

last_menu = ''
synonyms = {
    "quit": ['exit', 'quit', 'e', 'q', 'leave', 'x'],
    "return": ['r', 'return', 'back'],
    "main": ['m', 'main'],
    "menu": ['mm', 'menu', 'main menu'],
    "bag": [
        'bag',
        'backpack',
        'bp',
    ],
    "actions": ['action', 'actions', 'a']
}
main_actions = {
    "move": ["move", "send", "s"],
    "yes": ["y", "yes", "gang gang my brother"],
    "no": ["n", "no", "nuh uh", "na"],
    "back": ["return", "r", "back"]
}


def clear():
  print("\033[H\033[J", end="")


def Question(question, answer, type):
  if type == str:
    while True:
      try:
        text = input(question).lower()
        if text in answer:
          return text
        if text not in answer:
          print("Invalid Answer")
      except:
        print("Invalid Answer")
  if type == int:
    while True:
      try:
        text = int(input(question))
        if str(text) in str(answer):
          return text
        else:
          print('Incorrect Number')
      except:
        print('Invalid Number')


def clearLines(x):
  for i in range(x):
    print("\033[A                                                  \033[A")


def numbersThrough(x, y):
  templist = []
  for i in range(x, y):
    templist.append(i)
  return templist


def print_file_lines(file, start, end):
  with open(file, 'r') as file:
    lines = file.readlines()
    for line in lines[start - 1:end]:
      print(line)


def printMenu(type):
  screenTypes = ['main', 'menu', 'bag']
  if type in screenTypes:
    if type == 'main':
      clear()
      print_file_lines("menus/main.txt", 1, 10)
    elif type == 'menu':
      clear()
      print_file_lines("menus/menu.txt", 1, 10)
    elif type == 'bag':
      clear()
      print_file_lines("menus/bag.txt", 1, 10)


def write_line(file_name: str, line: int, content: str):
  with open(file_name, 'r', encoding='utf-8') as file:
    data = file.readlines()
  data[line] = content + '\n'
  with open(file_name, 'w', encoding='utf-8') as file:
    file.writelines(data)

def read_file(file_name:str):
  array_templist=[]
  with open("menus/" + file_name + '.txt') as f:
    for line in f:
      inner_list = [elt.strip() for elt in line.split(',')]
        # in alternative, if you need to use the file content as numbers
        # inner_list = [int(elt.strip()) for elt in line.split(',')]
      array_templist.append(inner_list)
  return array_templist
    

def menuToArray(menu, array):
  array = read_file(menu)


def arrayToMenu(array, menu):
  for x in range(9):
    write_line('menus/' + menu + '.txt', x, ' '.join(array[x]))


def mapHandler(action: str, coords=(0, 0)):
  if action == 'up':
    print('nah')


def menuHandler(type):
  global last_menu
  if type == 'main':
    printMenu(type)
    while True:
      menuActions = [item for sublist in synonyms.values() for item in sublist]
      get = Question('- ', menuActions, str)
      if get in synonyms["quit"]:
        break
      if get in synonyms["return"]:
        if last_menu != '':
          print(last_menu)
          menuHandler(last_menu)
          break
        else:
          print('No Previous Menu')
      if get in synonyms["bag"]:
        last_menu = 'main'
        menuHandler('bag')
        break
      if get in synonyms["menu"]:
        last_menu = 'main'
        menuHandler('menu')
        break
      if get in synonyms["actions"]:
        while True:
          print('actions:')
          print('-Move     -Back')
          main_actions_list = [
              item for sublist in main_actions.values() for item in sublist
          ]
          getMain = Question('- ', main_actions_list, str)
          if getMain in main_actions['move']:
            #move tester
            print('not made yet dummyy')
          if getMain in main_actions['back']:
            clear()
            printMenu('main')
            break
  if type == 'menu':
    printMenu(type)
    while True:
      menuActions = [item for sublist in synonyms.values() for item in sublist]
      get = Question('- ', menuActions, str)
      if get in synonyms["quit"]:
        break
      if get in synonyms["return"]:
        if last_menu != '':
          print(last_menu)
          menuHandler(last_menu)
          break
        else:
          print('No Previous Menu')
      if get in synonyms["bag"]:
        last_menu = 'menu'
        menuHandler('bag')
        break
      if get in synonyms["main"]:
        last_menu = 'menu'
        menuHandler('main')
        break
  if type == 'bag':
    printMenu(type)
    while True:
      menuActions = [item for sublist in synonyms.values() for item in sublist]
      get = Question('- ', menuActions, str)
      if get in synonyms["quit"]:
        break
      if get in synonyms["return"]:
        if last_menu != '':
          print(last_menu)
          menuHandler(last_menu)
          break
        else:
          print('No Previous Menu')
      if get in synonyms["bag"]:
        last_menu = 'menu'
        menuHandler('bag')
        break
      if get in synonyms["main"]:
        last_menu = 'menu'
        menuHandler('main')
        break


temparray = [
    ['1', '2', '3', '4', '5', '6', '7', '8', '9'],
    ['2', '#', '#', '#', '#', '#', '#', '#', '#'],
    ['3', '#', '#', '#', '#', '#', '#', '#', '#'],
    ['4', '#', '#', '#', '#', '#', '#', '#', '#'],
    ['5', '#', '#', '#', '#', '#', '#', '#', '#'],
    ['6', '#', '#', '#', '#', '#', '#', '#', '#'],
    ['7', '#', '#', '#', '#', '#', '#', '#', '#'],
    ['8', '#', '#', '#', '#', '#', '#', '#', '#'],
    ['9', '#', '#', '#', '#', '#', '#', '#', '#'],
]
menuToArray(menu='temp',array=temparray)

for x in range(9):
  print(' '.join(temparray[x]))
#menuHandler('main')
print('end of loop')

def format_number(num=int):
  num=str(num)
  if len(num)%3==0:
      for i in range(len(str(int(num)/3))):
          num.insert(len(num*3))
  return num